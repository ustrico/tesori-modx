<?php
/**
 * @package formit
 */
class FormItForm extends xPDOSimpleObject {}
?>