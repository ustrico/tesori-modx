<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'de6018d4af133e05ba78529ae3d9adb2',
      'native_key' => 'core',
      'filename' => 'modNamespace/47a3cdaec06352beddf40e55eba19d12.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '6e8b66571ce4bccea23c2d1c43a56bb8',
      'native_key' => 1,
      'filename' => 'modWorkspace/0474d23872c6b04c178ff8bae5617239.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'f3082361bc0457b71d304f61f824f32b',
      'native_key' => 1,
      'filename' => 'modTransportProvider/072084ddcb82a1147951682a1ec7f326.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '57b3b5ef01a7bcc29efc412b91c57d18',
      'native_key' => 'topnav',
      'filename' => 'modMenu/aa950fea5fc4666b804435cc32231750.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '81c9c83d2140d16202846ed904ae7ff7',
      'native_key' => 'usernav',
      'filename' => 'modMenu/0570c6feeea71e8e1c96a87ae79f77f3.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'bc44eb49da34ddede13f2fc2d76dd666',
      'native_key' => 1,
      'filename' => 'modContentType/bda44291121fbc1a3456586afb0fcdcd.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '609c271ffd34fa9d86cf7419d4d70b82',
      'native_key' => 2,
      'filename' => 'modContentType/d656f82b195fcf2e9202a40854b92afe.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'ddb9aaed8a59c10185ba0255130ab470',
      'native_key' => 3,
      'filename' => 'modContentType/a53a29ba461d949bceb370a218e4ed92.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '8e578b78f8143939c4b5ef1084feea4e',
      'native_key' => 4,
      'filename' => 'modContentType/eec3eba16a7e06239a53edd3f7ab400e.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'd74cb4a324bc4cd0063b78f66e46d7ac',
      'native_key' => 5,
      'filename' => 'modContentType/8f64fcb0e786537556210893e5639207.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '88f1c7acfe07f87b24a7158e7beecdc6',
      'native_key' => 6,
      'filename' => 'modContentType/740e191226dbbdbe3cc45a1e56e08c5a.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '4fbdcd402830b84cb6791ac7974db70c',
      'native_key' => 7,
      'filename' => 'modContentType/ef156b6a4ffc74662325bfeb5ce10571.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '8247fbad4a8442ec749125973709b5a3',
      'native_key' => 8,
      'filename' => 'modContentType/e49d09748d2796ea24254a0b1441c9cb.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '30bc1299159e9e882d92c1f4e2d046da',
      'native_key' => NULL,
      'filename' => 'modClassMap/5998d064ebdbf4140a7f45d8a4405513.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '5954eca0d472cae547aa8dc1dfe59810',
      'native_key' => NULL,
      'filename' => 'modClassMap/a2045d8750e1ec8250869dbd33163f5d.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '6c843f5912b9a66f1670e78905e62a74',
      'native_key' => NULL,
      'filename' => 'modClassMap/81c2a01401037e8bc45538f1dfc84856.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '56c22a629068de3b77837acb0f35f481',
      'native_key' => NULL,
      'filename' => 'modClassMap/8dfae944e386a1b847bb5c1822cf09da.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4b4823199ea00814c1620b759e82b74e',
      'native_key' => NULL,
      'filename' => 'modClassMap/edb47c9648959cd4c6996c3ff3d64e32.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '0e68ddc8d21311a06e585fbf9b2fb419',
      'native_key' => NULL,
      'filename' => 'modClassMap/ff0bc39f21f94753b97e5cb50deb9f58.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'cf79f9858fbf7131caf6f65b3ba1e575',
      'native_key' => NULL,
      'filename' => 'modClassMap/f0ed44663523b8f134eee953aa262336.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4ced8e2d8cef0ef93d9cbe902a1ccf4d',
      'native_key' => NULL,
      'filename' => 'modClassMap/7d58c880d69481c9772488a3af83760c.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '8fe3f69df5071ffd0e1bf78e3ecb161a',
      'native_key' => NULL,
      'filename' => 'modClassMap/a28b45a6977a17967bbb43f2fb904b2e.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53125086e9b14d966ae81f8886edb0d9',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/45219eec38eb4a5de91966361ebf8a04.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ee64c7380f8c55c7874cb2ceb2766d5f',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/1ddfe77a4232e80e5ee579cdb1968ff1.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21f2f77986763e5b25ef20d49ef4d2dd',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/ca5f917e66a045bde1986f804749e615.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38eeffa17b2c4e0be81a9652bf0c51b6',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/44b0ec3e82da294a48f06f4af0193d27.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd14847ca7dc0bb38387c63c0b5864ff7',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/66e659e331b5d525240ddccb609c6371.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9789c6f7f7a31744113c714458090c65',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/701cc5ed3add4b04339c50561e762dc4.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2090cc1ca201c210b06fbd8006bb2487',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/207b5174770c295c50185e430d2236e2.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5fb07a3377492dd0661fbc2d48c1d178',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/afb75dbad5dd3d88eb4f32639fdea9e1.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea34b9f3d68d7c8e5cf7b9b0bc8989c8',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/10db76359e8e2b4cf753b26771b866af.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58a0630419504ce06364d54d8e94898b',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/99e403d0ad2ed0da30a9e6498735b5c0.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f9059b322b5e90b0430f0408923197d5',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/031ec234d83554f7701d6caceef80a68.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfd84de3a66c6f161b733285796e5505',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/92bc2e65df84258d883b8b14c8788b15.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1133f294cb3a67209c79d87768bfbc81',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/9944af6183c42c1361f30ebea582b014.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b165063b6e63ead42c284a6d5c3b8f9a',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/4091d9e498d3c8b8d12bd28545dace1d.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e237ebd8552a8471b7fbbace6f6b202',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/901fd7ea06004195688139a759789cae.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '022b05fc05c6c53578271f768a993219',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/4e3352838b3110f9f4a2dec79936cb83.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10aab8315eb993af310a84d5b4e55247',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/5620bfbf08d337ca55b57592bf8699ac.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd23f5d1207a4a4a9ae377c5ed4ae03f0',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/cb0c4ccc05b6ccacd15b5557735cbc6a.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f779f84658c3c880e255e20821fe551',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/47a5c5142078f4613435d2a625fbfeea.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e7ba350f70a7df0d10ba038de3f7ccf',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/5e35bac6e6b8def8c618bfe32a2d7804.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a366b36e99bb09de72153d6b53189531',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/003dd9d768b17e70191df6832407f329.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c765f065cfccf2b45b44beb333444f4',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/54e36c6dc963557bfa839f6fca5608ee.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e57a83c92d46731a80a8af245e6d4229',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/881d90e2a0289a5dd21caafbb6c76616.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '12f508291a6bd060c43ac6f7c958ba21',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/77514fbc77c9730c2b264ee21bd0e400.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd29c16694a3345850b4caaa4fbaa6eaf',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/abce3a198c43c3fb4bfc4ccde35adc18.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfed350974473edc254ff71941ed91b9',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/89b3bed2c08c291c9f0a5ded42d370fa.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59576be7c48eb008a8090fc3ee60b21a',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/8662d163df63dee811997cb563d44627.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27fd973be4e0de65287408b0d287cc0b',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/78bea8ba6660e33b153a28e394071207.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '564881200cdd7c80917886380602a6de',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/240fd795c6115e186663562a88d6c496.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7b6bfe0f858866391e08045bee107ce3',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/e284321ba78ca58d7512e4fad79d390c.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99e9e73bb71dbc7ee9d5ca4adbda3085',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/cba2c303ca3871c4f2a720744f82d023.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '342ef5553da91ae2893550894881fb88',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/b5be48ec667f890281af603473925eb2.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8792288406ce46fed03a95c1c0982db',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/2294eaa1d05c2e228cc0ec18e1460000.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '094fad8a1b6cdbab05a79d75de2ccaa9',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/7d96f05720bea7a5f18fb6f44767aed0.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a2bab0629a865251e0be49256504509',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/d5a85b3877b45a03d0ba7d958814e99c.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39e11dd6e33ded5bbdf3e919d46d4421',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/6daa4c617711a07a82ccb051f6d0c6e8.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30917edd499a3b86ff3a50333d75ff0b',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/62c9c87e09b407ee6d8094a94fb9a4b7.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0d78c986c7b96c2016a8f53f0e6e32e',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/a903eba4a20615851675f5247c038396.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e27d7e371a966b894a9e6384888311d',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/7e1ed72a900cff8431dfd35844e3b77e.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c71eaba3e71319778edc8fbf6ad7fa3',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/996d5d45b4a6b1131d3db00a7b05d1ef.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44288bfdd43a045ca58ecc2af5d6176a',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/b7884e27f719e0ce5ad6d3cd033b1ebd.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b08be6149cdac5054b335d5d22a24ba',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/d5b6eec01aa6d2a1815c0df855a701c8.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ad27b91cdf39832b13029bd90917e1c',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/96bc5a08735861941a2e1d827d69b93b.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75b39db7c9ab76f97541a3d59120c5b5',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/b550734a066db38dde9c7b9f2e719e95.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2023364460dad488c3cb0de50695adde',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/1cd6c2324e74c93b3664a9915037532b.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b02d7d3ecf010af23f32080656219eb0',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/f9d23ce9a2a7fb8182d66f3a65035caa.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '186fa3810fc4d9a16fe674915be2fdde',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/ea550c2562ebb48eb3a9c587e18b1563.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '193a2dfbfefcf1ef894598e27d165985',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/8462dc5562d5b1eb3d15255ed6e90c7b.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f9cb9e7990f3429cf520a19172b861d',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/e373276c8d69b7fa1403db9c022c0476.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4ea8ffea0ccf851b16b3671fba4a0f8',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/8b21f9dd439d7e729fa6ef0cd54a7f08.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a63c9dc9ea223dbb84c0eb14dbb8608',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/a2a32597d639216ebfbd6bdf89c8da1f.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c67d563e2d917f313a1e1fbe88e35931',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/404491a7c11516dbc99496f7eb468496.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78bb790634f02452517bbd9f03bf5745',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/5cda63d7e94b509f13c17dfc32448f2f.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2fa0a7c9be8de4788e70ddf004b857ca',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/d55af1e3f502abdaaa47f55bb74494b7.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd569771b3e0b4133db0fec5889d346da',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/7a8285eb2bdee4763358ec5863bbc573.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4cc6c7080c96ca9209ba6c0ba4d67579',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/8a1f6f4de08ebf67527965f079b9c2b3.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3183c980bc539ff86c46d970148175cb',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/313f8e2eaae70ac163ba0f9ce219acd6.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bde0cef1074470ccb48274c850629440',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/e0d08e04d2cec7c3c39bfe0ebea512b5.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fef5aa7a87947d0dc4ec2a2dac2948cc',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/e59d0e78b316ae6e94e187cd885ca0d2.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd8e904f44a994399ac9d0957d7d5d279',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/d849bc654965ef61eb27733d801cedb6.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd91a87635ebef21962bab578aa54dc1',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/93915556fb1e8957624bc40877f6c4aa.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '216fe91c10f3fd6d37dfac937881ce7e',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/85146ba4cf30a0a8fef8122f7004f109.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c73e4489bd913a1abffde35091085727',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/31a70fb873517921015f2c040bf2a942.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac370a605631d69f0eb242d2c14aa9d6',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/7afc4504c2dc7d2554d7019a1c97dbfe.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '03b0802a290a8e6eedd28e21473d3a57',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/d73e53f08a981e6b721a3ba1cd480dcc.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98699fe5725eecbe8603f764e1897f4b',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/6dbbcab411e5665f7192e2ae6ac30859.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a61fc399afe8fe103733cda074f0eb5',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/124d0aea4ec72b99ea50701eacc74d24.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b76babcd6db59276543b84c4bbcc0fe',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/48077edc07d027e8b3d0e7dc475f4a62.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '03ca1350b058348ab071b149610ae2c5',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/d0b99d3fdeda7423103bdbb0b5ae4d1d.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41bbe6ad246bcd44968322079c96acda',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/88f9c67c3b937f5b4db0ae3dd558c487.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'adab7c693eaeebfa6f888dfd57f765fe',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/ffd07e562d2ab624059a90ac4e75c026.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c8db428f1f043ec93ac510272748b7c',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/345490346a6dc000a3fe208c6605323c.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c967b0341c3e6c94656bb415bd9eacc5',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/406644c60ace2582a6833e1b6bd639ae.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e6a26f2aa6ab86afa31abdc64c732e4b',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/c1f0e0a6222a9d7a33f628729ad649f7.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2dd61b3b9c64dd371406a8f8590ea043',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/a078adc6f67979fce70f89ee6395f276.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc83f19179b8bcff96c59c15289b77a4',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/b22c2ed05b3de3af454909cdc2b3a9a7.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2121f2decd76699a18bf86c8aac8cb00',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/d48f524ceb1992adc355ec93b70fc541.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '945d9da9feedc94f4e99ae0fea241c6a',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/ec1d638f8a7126af96340c8fcf7b4366.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7f0d64aa5da321dd37faabd44e13e41',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/710d5c23f67bf8d0e4b838aa4a391626.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c54db366a75757a7824e7514b4d95195',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/2ceb3e4b2e1ddd626c434c8269e186c9.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41b7b87471fc4ca71056b74e7c2b411e',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/c85ace3e6590c4a2d5cd509f3e43e390.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '25b409899381173cf1a3867dd95096c7',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/02fd9e9e7e2091f5a3aca1160642fd7f.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3175b429c240c16b6ebc53b5865b7d19',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/4a2b16ee74d539ee51e29e68b9344bf9.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91668f3934dd6c2a38a10202b0237f54',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/df703a05d1766e8d75a25eaf3531c8dc.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be19d909b18a5261a069d8ea8dcc0ecd',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/b1fa4671e508ee34cf05470b834cc50b.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb7c56bb487ca9b9f527c022d9692ae0',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/ea919c7b607e3cf9150380eeb609042a.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9618eb2a74db6dc082d7508f78dc01b9',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/4f235b30ea1a4c74682593cc55f74027.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'caaaa225fa4493a91bf2986704c093cc',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/66da90b6ef9dd6e4a5ef8dddb7e5e321.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6901ae8360e124e9c7ca596186cc05a2',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/d1e8f6cee7a0d5068bfee3f3dc6ee5ae.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4349dfd73388b18bde32895aaeb43889',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/d78837257a2423b40a9fee1fd31c20f3.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6aab4907524a8e49075d015f4333d785',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/bbef62869249b95381475294490b92c3.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2adc10b1b60f6528fa98402c4da8ae8',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/e48ab91e89142583e9686a03eac702fa.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b38a24169df36016a1a80b55689fc55c',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/2b2a38f41cea06e879f7663da6505027.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07e22f4d7e0ec9e4f2f2c4c1069bfba7',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/f57bdac7b7b881686f6497f3fdb57c9d.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7522eb762729a449e3c7d4a39a7d755e',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/9febc9b53a9bc2cfac7061e0563c9a28.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '258b6a36d2adf1296e837d9135119f92',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/9da6082de48cd29cc26d930753bc57c8.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '018aca8565063f93f6d148fe4ae62ad3',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/89fbafd445a74dfd8ac40c9742790306.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14eca2a00833f0623a98a206e60cdc5f',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/e27e47fd37300dd646a1d714add4d3c4.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2feaef4c20485e5d2178ba45455474db',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/5f1f11eb6a84990fe0f49c5b7515afbe.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b86844914efb06ed1e88926c3c3bab4',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/ad4e3fffbe5d36fa7a948a47c423a2e0.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9351f7371e8604c5b47dea65dacf58aa',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/0837991d016cd7982030e1b7a16f069c.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '489fdc3c9902a1132d0b550345f7aa0c',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/650be09d92e386bc9a249731a2364fbd.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '641da7df4e29b33007d7dabca5162696',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/18fc99dc151971e7b4db5da86c600a9a.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17ad4e15360eec22063bd641562f4b3f',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/171e52782cffe0fae5148b9202aa6e7a.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2fe7dc2680984fb2844a094c7d56b80d',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/4a8e0f88798d1fc0b22ea4b28d6c021d.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e84fdd9506133727dc368f47d981137',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/104b553b8dab4e06bbc8c15f91ffbf51.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'baf7c1a1c48433c58fbf3522b6a96c61',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/7952c03c30fbf3618169feee133b14c1.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5eb67c52254a62bc905cdc19479fa2af',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/2a03e7d545ac6e6132fcfc8224d27630.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '70802938d912c891478516fdbf1564ba',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/e999c850d3c7795885055a0e48b47ba5.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9efd59e224ca9590652dd2a1e7569066',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/8c9772ce6b1c5d2503e0a61b94bf2762.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10424621b1537e23f01c3e8c0e774c3b',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/b0525240feb1f195e9ce3692a89977e5.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '468428582a0eeecd8e77031e454c0cba',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/1559f7bf5c66c3bd6297ef56ecf06f11.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '82e836661c67bf23ae2eda8cdf810eca',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/fee6d220746b7cf9721cfe46dd2bad7b.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '923e8eec59c39bd98b1db602c3301c53',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/5e36c0af7e6287fd801614d38ada2e45.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3939e8730c938f33bdf5751a187628dc',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/ed0ff2c638b25c3a4c1550395bf17a05.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b9e05e4da7655ba893b65a2e930ef42',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/b164c5284f04fa34583112651f7f0edf.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0decb1e66a5c3d2f6e59b8f8a2e28f71',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/c17a48599a839d8e1ed99901868a60b0.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0fff30db7ddb73ec5c984fe31cf5aec',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/d5043f042333bed49e330cd66870697c.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '391d17fa540d189af096b70641b176f9',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/53b9b70ed47e0de5334feec9fb5122b4.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ce48801967a25c2972080a594772d3b',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/0098b127da68702708b1340a45fbdb72.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a117266494d6f04b81e7e7e455e74ec6',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/201a41c937d9fa862476a83df8cdec30.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4906d445d70f2f5a44a77b27c5768332',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/fc9fc4b0a81f399cd33ace64d9b3d08f.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c9de5f89cbe5ca4709d12b9af4e92c5',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/35a1754c09940011f12a3d0d37b5782e.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '311c2177be13f508203328e20c8086d5',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/72090a0022cf83478e760ecb5a38de35.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31f29fc237bfbf2e0580411d0318b76e',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/a35cbdd1b8f85d63f0c38765823849bf.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f7a917e22973f539cb6c20a9cb21f42',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/3e7108ba8a9d693c9a91466367c6cd40.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9b39c5c8122663360c90e5849d6add3',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/3f79d83ef087eb8b1779b704d37fc615.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f8d487437e892919449a162a56349b7',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/6ab6e8f03541f3d96de13617a3fa783f.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76bf52534c26d2bdd9eec408d8831276',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/db1f56ebeaea04ff386b99410ada317b.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dfffd12a2f5c429ae03a0058d74ce651',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/bdf4261b168f310c9c786308c4a45df1.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '400a3f3c96e77e3a0a46dcf724942de3',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/042397d2092e8986e1d9d9ff91bcdf68.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4c296903f0c502a9342659490fc7d41',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/fb54ceb5bc0e1d8692fbf3e5d1f9b0a4.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e94a9cca622aabf5c95be4f5d05c6a97',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/c861b2e8064eac1744fdac4e7ff26da0.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99eb732a42b91a571a6e5756c7b612d7',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/9ced042b15061651768d52fd882d49d4.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a7630ecaedec755d99c0accefc219cb',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/35b92330d23d04bbabcf094085f6bc47.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8cea35c91e1e30a5a6ebe25a9939c341',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/ae7d956fa518f6011d273db3c6e6fe7f.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dad1243c5e4ae759422110044e2169d4',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/6d1f4212eee7d6d6da137583981cf9c0.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b2dc2e60ab2e179e751a272a3884e87',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/5459602c934e7784506ada74e9c82e2e.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1b81fe3fff477d2eddc7940ea7526b8',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/f487e1ed23b797ff9ee40efb071232d3.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a383d9630f1b0944b8758be928680a35',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/e34340d1e5312c7e8c3fcdaa14e9aa5b.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb8ad768a046a9b7035a515002fff109',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/edf0064a4d2915b1f8fa0d86e6bb16ab.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2f81abb9fd98557d876dd26fae9b52b',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/6b9306c5d53c72a029d1e0d2ba861fc1.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d731c54558a7ef8184c88295c477044',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/e92ed18e66ab1663cebd6d27c0605f24.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec19e0866a31f38793462ed0edaf5661',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/6e3d30f7612f6e383a60d83001fce621.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0a93f601c87bce210c7be8bb14302c5',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/ddd1c84ab631be2bbf60d6b5d39f7f72.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '131eae7a0fba74720c8a775073428792',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/544d72ad462e75a62dbe5855816109bc.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bbc82d17c2a95847061de648ec1bf30d',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/a48f1711621e269267ccd52219aefeb9.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '823c8f4fbab1d04f80860a9e47543033',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/14187cf4b8101d8d8b653b0e2a4e636f.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32bef8157b31c2da47c7014056f7aa8a',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/7e4f1aae375af08ab2149b1c41d8f285.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '954072d5b3455d843769bb83c5753cd4',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/890e1b5e8daf5edddcbcf8ce5d632bb1.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6026e83a1bb165c6a935eb5b33943936',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/0c461691f2358ca0d6017ce665e52adf.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54396a3f5f9719c0e75de261a2ee5620',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/6dd45cba1031b695c71429422fcfc6aa.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '08f570e104236880071d309730ba709b',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/b812fc5da972b169aaf2f5d6f6810850.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2b23a8ed2a2f884013cf36b4e1b98cf',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/1ca5fd606f552597d75ebced0fd4574c.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9833808e19bc3506ddd83a6f8776f885',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/1f83232a7da650927e25324dc57590ef.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e96a9154162c94f15b7be26883182d9a',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/fbd7bc64dbf84001ad3c5df2383fb409.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90525e2ac5eefddd2199828deb0ca190',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/237dea275b1fd3458cd8797e1d01567b.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '248f1ed29294e796516189335f99fd65',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/688185cc409341c0c33f87b6c54e80e4.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab9dc1599f583366c97f1fe6712a08d9',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/aa7fab817827b4e783229ffce354c939.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '320cb7b9fc93c7896caf620d80e1f56c',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/8a86c8f1b08d3f2930ab1460168e3baa.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4da19546cd2a0962ed0740808cb9935',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/53aa1f59ebb8eaa65539f9d74db1ebbc.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfd00f25d7a01c84b40ff3d4474c9f2b',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/1773e4ffb4f3e585070aef468bd41dd8.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d04b5417d10600fb1a620f7f2e1d0d8',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/3baa79b41324826da0a67517072c214b.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8fd28b651cd1341db26a4c95b12d744',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/56a4046914a50b36d1eee0d4e2a7609d.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b50d21bcc80737ac32ed99266f45ffa',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/db042374ceb30c41d81e2d75459f98d0.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9c7d57aab2a162ca43a23a5a32c1062',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/5e90c08f409a3f6c039add59b8508534.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ecdedb08a8c32bd5f8fe335db2d54af2',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/753e51776e2000fbddf5a51f1821b251.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31427c0bdbb28b483be9fd403461fbf1',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/7bbf179386fd8acc22689a400c2c3a08.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '61e609b6b1de15e056f43dee1efd144d',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/2542389df2a54e23c150c1ad2f3e9c67.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '148fe38931a2857786e78ec2fe36fa6a',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/bcc2cecce6c1d8aa1d08facee6ba4a9d.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49e7c302222fe57904ce2cd1e4d3f0e4',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/64524cb0cb0351686f3361a25f902c2c.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f0ecab5f309a0e6bcd649b10b6644f8',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/ab9b433042ec0993d4c8c31d6eada85e.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c1364fa1ec2f350b641abf48b66ce09',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/5e960aea38247cdcefced400d35291be.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd28f258dfb53fb101d6cfa0e3e1cd818',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/a62f31531d95af6bcb9ea72f153b0000.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f45656c29936d8ce49ed824f275f8750',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/f29c1db4ef77d32ef3653665e90ea4c3.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9aead7ee96fee08d3ae59480877cfa1d',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/8cc7c9454b03fdffdf3966d82ba768a3.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4850022fe83f9b7a31764fa57b090542',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/2a0e9e1aab5ae31202f63b4bb891ee27.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2185cc36ec33200a51cc2af45a23bcb4',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/9a763be95b51213739cb3dc30cf03ebe.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9fcd221d0905ae1b23b6ad916787470c',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/d1d869b20864d6fbed225e99a3bee968.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c06f62c527ed0774b6cacbf1c6e8477',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/3b6485e830445f164cecf5537c1fbf4f.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '735adfe776835c9f1d87721ded4d50fc',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/2e8f387e5c1f8c02e95e545af6e8e188.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f8c2656924754b334412cb33275ab72',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/537b71c83be48d84c130c2434a4ce245.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0ebb8b268b6c2a264094d28c054aadf',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/22ebfe6c8e07ba92fe2cf1dcd8d57bcf.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '227d7397bd7af4a4006858808e2bea0f',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/d8bf04fed1a1f954b26bbaefe138188b.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b1c6976444661b903cdee2a59d31a0c',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/68aa693eec7ed06bcd318e91bc6790fa.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1a9b1f9101dd5102d05fc5f8d997ca4',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/254faec62bd7bcf5d40fadf63af02b10.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9805714df48611ec5d9c665b9e8b9cb8',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/0ec40db4b134c3305f603ce9217d437b.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c85fd1ab1a1653bac996dbb5620e2548',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/5c6a7fa73f6450cb6b57a2d822dba721.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac914690635f7d8227e732743b5e6feb',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/da2ce17f187600f6257da35ad090eba4.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '929e337fa6751cbee218a12aa5653bec',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/f8a939f577175595158f5619dfea42ec.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '029ae054f69027b688e8a8f958a2b7e9',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/5a1e858b7df060246db259f74137efde.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ee0bfbd150e906b4a91ca22c53c6e00',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/39cd6bcb46e9164a2e7541ecfda05c80.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f32fda0906ded84aa05516b7a1cf31f2',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/e749fd85859fe5fcef2c6faf83306163.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72f4bde19e0b16682fcc0f339007bb0c',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/6cfbf64fae2386b65d204972ba4749df.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '559d9c050ab1019e50df6cc8fb26b298',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/d9032b5fe12cba4c4e3390aecb38da11.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dded1ee51992f591c174fa4864b19c5f',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/b3c4ec2ef6647eb59f7738c57f25db9c.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d254dc4678f40dbe5bb7351b74b2e5e',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/a26f496fc1fb4bec078e7032a64bf22a.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc7d73475551c6edd9e10e2b1be59d59',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/6dc107c58e455fc63e1c17207170e5e2.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '643111b640f8ad0279d2510f7b49d896',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/97a6c950f102aadd9fe9bc9c83ea3a31.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f722986733d873cefd08078d7cab36e0',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/9800f9f84f054b13e2427bbab02a5fc8.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e47e67b0a85cf1cfa1f1332d85b95d32',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/4ce22d657ef171f8ad37e4ef058ff19a.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '657cfced3360be3bca3077afd49c98e9',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/dc72a614699775cfa2168b5617646331.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d7141318a5b2e0f5f3c2b8ec776ce9b',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/124a65ff6d60ef05f8d2e5e460131df3.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e099d2f9af6c19bb0888e2717ef63407',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/5abbc572a45ddc13f89e694bf5c5e993.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f3dc5f6f759e3cf7abef7639f8cb258',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/2aa9599dccc0c606277164802c37a426.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fea3465c4b8fcbb8fd2083ccfd4e39bc',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/c7814cc17a1e834d87fe51adaa0fce1a.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b83cc55c6fb31fd0fe74b0f4e08bf96e',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/9570f5ac5bed83fab335532bfe5659e5.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26c255b59cd30cfb93a9d94e6d584421',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/8082c6e855070a582ad4ed2b1b151db9.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba6aaf57747cc0fd0d4c3481d27385d8',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/bf81489c2aaf4cd49f36dcaa35fb7722.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b15ba4611b60cce8c62bcad185bc0dd',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/1c3f7a4fcf58a315184e852bd64847e6.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77e7d24979f2f14bf3495c34f4f764b6',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/b9d19b4ce78182598efd2163b07669f0.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66e93a5cea4d56a51997f36128bde77b',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/fff74e29f53308bd5833cf41e47c0a51.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dadb7184c6d85dc8a8c835b136c0087b',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/3c7032a3650dab8e9ffb68d4041f6f2b.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '617c06002f260b4722fe3f1b7321b825',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/a6c27b0847b42ecd881b186dcbeea5ec.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40ff34642a275da92255f7460bd0cfd2',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/1a82eb4b852e6bbd6fb580ae0944f825.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de93775abdcc5eed726d9e163e14f165',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/5438652adb7fe1435b45cf0f1a0333e3.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c43abc9bc13cb0e1902eabdf99194ded',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/4952bff8453ab9377c6e7d9d23dca5ec.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7729415e283cc971c32b5707e20e801',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/d4580d95c350b8b51118b676a91e7280.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34d2399306ca37e5d781e689b60a234a',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/e37b0a0c51a17e44498552ebbc98d9bb.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c435def96cef30d50f704d92116eeb1',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/274bacc9373b090f0048982def1c3aeb.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0f1122e15b820f2cb29bbd60c5582fb',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/984d7d2e79d1e70bade01d9b5b0202aa.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0826044847ba45e77c1e070fc491931d',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/ce2ebca74add9a70f6f329ddb058b463.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e0dd4aaa1a7da8986c463b087f25e6f',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/d620205e8d2a9108b30e5439eb1d1f8d.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a4f418369f3263b77b031038bb63c7e',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/eac0ed32cae38ffbb02ce19f6c214f95.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3321ec9747d8229525860ce79a2a2646',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/6b703a2ef145bba1e83a3bb64d77b1a9.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df7975225b9e71e427b90b31427ba0e0',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/38be92adb73bc518df32b1a44f10a5ce.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b82bc3b46c78bc952bf42a473f6dd1f',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/a103e46cda17b4324cbab32a83ff6150.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a856a493e4f6c49542064453d041e084',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/3ac216c41b52bba096a26292afe049ae.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b84c2dc1d62cbf798d6ed5973335e877',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/4b195a77ba05fe5546486480e02c7874.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '388fc5d056e1871bf6bce452462327c6',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/65946ed9002cd548648fdd2fb8daf898.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18716952d9111821450f552ef1798b84',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/3e1c9157c89710522c3c6a757eba0f05.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '286275b79cce581d77f2f327dd7cc064',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/460f1d004442d6b21b3824bbb87fa9f4.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b95fd04811adc53718e97ff24d3f0b72',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/f9a0c8e8fe448dedd48f2557a90ec80e.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bebb7467d284ad20bde7e0c467479f6e',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/20ddb6384b9f7e51ed2f53930d4344c2.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4efaf5f53413ba7cc54f3e96fcdf4898',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/626c62a051dfca7a3bc121f258fff266.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d05f03f2bbaa8c04d5cadbbadcb3c3b',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/9fa27a68deff1f1de87af367ceee0f5b.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3083dd4b6077efb7345e7df46ef0bee5',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/3604b8ae7d5ceb80e9bfd036d129bd0e.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6561f9e5ff56aa24ae320cf9a098eb28',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/e571b5c326bde6b4770e6fc729e069de.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b301a263dc1ef51ad9c150c32a42510d',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/1447ea86b4b8abc65a946fc82c625516.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e8b574436235aa5d070c928dbaca829',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/7ade102052fc8cb583360832c773a3bb.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a5506eb525b7ce363ef4a13f3253fbc',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/da54c3724a980ce5157354a3d03fd046.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1786ebecaa3029f27c1cb8adaf16725',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/98c59a787957da550e557876d078598c.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e98ffd1b341b11bfb19f6844b86bad86',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/d068b9820cd6c751b255858a451fc08c.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10a31dd04424bbc7f30233daf05a47b5',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/13e2e02979c3951301b57402f5957bf9.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb26e04cd962bfff402810d91b17c639',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/0027f134738995e571fb3cdb0b4cc4ce.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f3ad5a7480bf942673ef2d4eb9c9962',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/1285b77eb6774dfb9cefe7c7b3d3a174.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a496ffd89e97c488810bb3d5336de25',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/232c87352b2f3e5011ff2ab3ba0d4860.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8cd7a39a4fcfe7cba99e848360e991e',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/8f85b87091dd184de5ec501c6637ebab.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37009705a426bb2c016ae2934c4a9d07',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/5d9322acd8d102567c1c539acf92213a.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf00d1475aba58b304a64228f273e613',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/a598ef9b6cd829e25839f188ce959726.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18414ab51324175163ac4ec43a7d5864',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/053ee9bac51b4312dd7fbe9de5456867.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f23df9a67a62b6ef29b20522d8de1c7',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/6128ee0a6ccbc246abc595168372ded9.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f263f6cdaa8a69285d6ae69cf069770c',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/ad0fb977b7fcf7c78bc3ad50571442d7.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d47e1e9615608810eff125e5efdc65f',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/7f9c5eac780a92b4ec5b904517945e6d.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7779a364db945d3902fb2b137db8509',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/3128193e84cda7fb9b2ab1d7c6d22177.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fb238c940521d9314f68b503e198186',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/ed44f6a8bfeb8b9318ca75390cc9796a.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9db937766d721a8cf4b9eb219b007daa',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/43d3d90d87445e50896de5d1c57f3730.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63f082729b73c185a0eb5e34f8d6008b',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/af62940b72d2bc4fc91c4a8f134e4aa6.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '932ea0e97d5adb520ab45b7c233b974c',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/6a09186c30457f44d1b5ac2265c8d510.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10c17e22fc41ca34a95d754e9a69aaa7',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/d4b5af72bce6d34c83d7ad8009c35198.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b162e90a241abff13beec494d9a9dcc',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/87a08c4f9db971d70d6367f2c60a289d.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2047ff8ed34c64199509548a88485fe4',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/84faa3644d58c9a2f06fa92afb72a1b0.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7f8e6032853d99b6b124992d17f5a20',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/48c26a30fe42eb5ba8df0faddd41fd2f.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c00c8c06d0421b0d1389bc1dd3dc1019',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/f4dc7e38a9c576a5e37d6a2ee0576b95.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29f1091b0b3f8d12db463eacb8584394',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/a8a692ef271d27f0a3bdda77ab22f943.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7345ee34b9d2d8686d57c88113f293a6',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/5b3b44c7914e39005ea433337a497682.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2e830cfff5b2ac39b30805c2d1a166b',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/6c495ed818590975b347484923c828b7.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ef2ebdf2620d4a0fb6df978157b5431',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/13cc0da81f3ee6c0844c36f26801bbc7.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9798bb2be261a2004e7ef12662a61eee',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/fee833828c19a8bb0542141d7e1716b7.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '784ed22601d26cf72846e1bd0a90af7a',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/691eef62badffa3fc52d134cc7cda959.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5de545fea64d1d93c01ce184550dadd9',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/0321ccbd22f94e2b928ec540edfe99ac.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2aa175f25d0771aa854c0691135e846',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/a5f3fc3f1fb9dcc495450837ebf170a8.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59f0be5157cadb90fd9815107119a98f',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/7dd49001ede35f2b9ee75fd7e699de6b.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72ccbb0f376ca40a91a9638476aa24b7',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/b0656456f5249467180549d639140a1b.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1bf0920151a297a26e04b6e1b5cc226',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/471bb865e6774267c3f31efbba37ddd3.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff1e446c7f858dc7bafc9c1869b4d4ff',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/f957723e04fd3f1b611f8985a7d7a5b0.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4935b463fd1b70080b7803067473d7be',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/5b4c412d221df55f9d827fe28d4ae7fb.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59c340034c43846e729f7ead22c125ff',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/72770c13db1adcf4729ace30548004e5.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0f7b1c26386575686fd9fe750570d8e',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/c2fe6af642e672977cbf04c953199b53.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f9ed636908b67169da4a574d21b9922',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/56e80d9caa734ec9f4146e5db26b3fa9.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6bf5bd502b7237438b9068c015c228b',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/ac7c44d42d78c55bffb828e190d281b4.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '829ee314c76152848ae169dc8de5d1f5',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/ad3d7e1eef14d283d0b6cab0450110fa.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1307abf454374cfd715b152a788f531b',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/207db895a3fb171b55c30ca4aff83e28.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83c5761831e7e573e5c6c2d85a9be8ad',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/ea034eb95f7bff5eb39168dcc1728022.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91a36a2c665a974b6afb65548294486d',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/d31520a76e19dffe9e955f24bdf4dc24.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af541c964fc0ee51036880460330e22a',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/ab004c04d99f72f866fc29a507419751.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5ebe3dffd7f19d0604e7bec46b4b38e',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/1af60fab0cccc53e3878863bc8b60122.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0651635754baa2981c7d2d6bca37be9a',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/e2330654c19f0be639bd83b37608a761.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f5cb9479e519d02d5af760fc739c9d0',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/6356f89167495c5cee3692a7379dc693.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '748c4b254d91df97514a393f93d39daa',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/f44a52d87b43864d1135ddd1c574e881.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c99e6f77f9d4eb490739219bc7751f3',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/6207e6f5cd11e618422eb621b76ba2a4.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '933b4e438c570abddabfc786012ac1d4',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/fdfcfe4b4404f06f7b4b54ae9c858fb2.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f788be0df98e0e7cda67747f060056b5',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/86eb79ca1e9e2d79b8cefb19bd333010.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e153bef554dc6df95a26247782b40ee',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/60398896ae5c443c8bfc0e4d4dc5c15f.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2768200bc72bf017c23a641f2d9f9a4a',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/73bad9b9ab47c6d9757a94a17392a09a.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93a36e2d5d6ff9e79230c6be0a971b5d',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/44268c42101701987dec6c02af538035.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89c53305fa418dfdbb6cbc1f5ed8d294',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/f084cba1ba2197b9469940b6ef96b15a.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd64b2b37a3ead28a778b66ec3b6d4970',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/71951eb52c354cc8bbf5efb2e55d4e4e.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3820af569d4e74daabb0245bc23e71d9',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/5c53a55c1f1a1956e4e5eabed94f675a.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e330c2dbce12763a0fdfb232056823fe',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/1fce8244a5270e07d01f051e009efb94.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8556593c939adddcf2dcb70481ee0873',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/68a504125b05f23c4218707e43e8b596.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a871e566f4a533053706ae0adca79b7',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/4ac9013fab9a0d8e263e55dfea2d8628.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aefdd3ec381a08b10112677e1e3c8b00',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/adf0e2b3888e619b1542783012c74140.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a99ad13ad91a1a831b380f33e04b0f12',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/551567b327c123c6f7e2b1a7c08f5e22.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4fcfa65e282819cc429b9babe9006d5',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/1151a4e5f85284c5b89ea5bbe7e7c6f9.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '592fafe80e6596e062e35e05d6b0d5e0',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/09c24b2b05c3225fa05098fccbf4f85d.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '998b6905856138621d65637abff4ff47',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/f22a9530f6f497600e816d3da8f3a86b.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f737ed321295c78ae2f7298b13b15353',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/07f9b5568be1ea58790555a3ac874af6.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b25d04add408bc186fb3c7fc128a9fd',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/15abd083b9d8aa3347748992b53ea1ed.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9bfdf2a758bf5d2f4672b2a95f5cf7d2',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/a459138e740373d1faebdec6342141d1.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afd94f4255d58048909e95eeb217c025',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/567699fe5f42a049d910a1621ef2b99d.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0343e282564ceaf615accabb32ab0cc',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/f954bb5652b2a94f8639bd047d36bed2.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '850ce5a91f8e3715c4226006a16441e6',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/bf7a050db25fa07a89ac82d8fc78b054.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52bee984beafe1b0a2817b81f8bc5571',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/cf0e1529696840c71d2c75f28ec1d6ef.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6d6d4fa6978707ca6e9552fab99b5c4',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/983949794ac640dd970d036b8af8a0c3.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eafe29db76934efa46b0aacf412d73ac',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/47d372206ad5cbdd3f09e36c6d60c713.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef7cd1da1a72fd0b00853af789b09cb9',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/14788d6add1625eeba878a3d73c9ef04.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26f97044b53bc75c539b48e6790f13f5',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/7d43ce555a59c397998636e6d3dd0241.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54f909c845734c1beb2064674e1018f8',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/1b4e49b3f2e02d18b0d19fafe6e801d4.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '366d41381c7b9cea27a5f654a811fc51',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/af8d60d721ed380869245670cd28b833.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd36ac832680a1adf1ffd11d2264cd4a4',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/45dec24bf391f2a6c820dafffbc6bb88.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5fc4576303cedd8e063f9980a904863',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/605a3f833870d2e28a6f84da9fa46967.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddf92c1be8d6982af2e19e5bfdcb984f',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/bdc0ed2acb91ff9fdafafad0c2df3bc7.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '841efb304ca3859542336c3fccd7863b',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/95181dd5d1c0edab297217069c092882.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62dfa58e3d33b475de401591b872eb9d',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/766f642a559fa8c672ee5a6f771219be.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7daab40ab82b166e032f81b2bce4b103',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/0e971c2442ca10bafc673e21a862212c.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12c3b756ed7fa62ff9486dda9cb4feae',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/e9c6353fc149669f1fde8ba070cf65ff.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d3ccaec5cde89bfb802cceab4706527',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/ea18c16d0eab263f37d6f621416aa6c1.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63cf349934c137d151bf0739c429c741',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/96775a4cd84565290794804dd32dce28.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29d9c2533e5b37d73bf8e8b7522dc31e',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/531e7b456ac21fb7519787a586480eb9.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1da02837f453a546f2769d624a9528c8',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/28a9bc533613898d2dbc760801e9fe96.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0331fa2b4923a4d825cba0b4cd0229df',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/f1ffbb33660e87b19ddbe125ab8410d1.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af8ee23024227bb44e194c6450a86bfc',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/a8652dcb10233e745b162f02174cb8db.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '390fd7b972ef0f07808e87b783abbb4f',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/1697654cb3b204a57fde9f095a65bedf.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '487bf3a06e8861895c7d248f9ccc7c11',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/c1316c84cae59ae32099d3f80b61a1d3.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26995f6cb4dfd01fce5d97f2836864b4',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/70214d1d8b7b03005e84d5bee769fe65.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2ddcd2e8379e1708e63f0f6d03c7ba2',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/ea3bbd9e04d7ddc95ceae625f2c146c0.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef330011157be4075de4576dc59e84ec',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/c5d5cae5d8da2d1c9012909bad0bf66d.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91341bca778315bb98b5e69fb92eff67',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/56fb17915d3a7f65e0059b071513a368.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41dba9d89fd3c150312a8f338ffcd14a',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/fb5ddb4dfdba0ca1cc199798eb4c5020.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5934898780e8d692865b43ce75902b84',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/76dd2a9ae1704235e00759c88be914bd.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3116f41e5cde0712ce859e9f5d21d6a5',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/f410c39f56d8496b52d894cca4312511.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a86a43b79285272e28812f43470996db',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/08c70384aa823d6209b1e5dad0c03e41.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f85ab1a64c3287f6b56ee7a453e874a',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/4a8d6c7ae5545fe52bdbff3b8c108e9f.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ac71587a490603a0b2c9bb028502cbc',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/e4357b3d1c4f32d8b5b288d15ca0b7b0.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3620c35eb6682d89105036c8e5b5ac3',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/055931d4762acaaee5223f1f62c767cf.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5485c883b6c1f1df8faa54bf29728a6c',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/1e979aada51d11df2997d2e20e48c2c4.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a3ffd806b304a76bd0b74ad5a6aefdd',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/21b3a9fe888b613d529eef01fd3e3164.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23b29882e0e34e6edf0a5436b7c6d892',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/9a823c089ff907d02ceb01e37398d7b3.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f12d3067ae7925514691bf8708a40dc3',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/c4b9c600440b946eaaa36032bb45ec25.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f656328e91f26485dfcfaf582be30b21',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/da04cb336a29457a6fde2443ec29a53a.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cd687ddfee95cdf16e6557f29f8f02f',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/02e53ff70d41a5d153c283586d4de6b7.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd962307ec131b74f3dd8b5111338d003',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/e979083102191cb3320d27ee47de407f.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea8b27f2e5207ab2fadcb02f6e5ca710',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/7df529d92aae2baffe702d39eecd1438.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7253114815e0b3827da689a0a365fbc',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/bcb4b8470377ac86bca2f348f536bbd4.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c34bdca5d5e7cdc9d82528d3607ea1c',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/576fc5c5b909632d85f09acd176481cd.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b95775c156fde5bf1217087e0d078946',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/ec49cda28cacf02b40f10eec769e421d.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52c2d0f796ce87fc732719bf8cc90ce6',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/3f80d71f01552af92a23cf7aeb23c8f1.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2107da11b1c7c2d6ab8c00b27aeec74',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/4a5d1a8cfdc13d9f63b7279e1a7304a1.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '456188c7b568d323d8bca1de215ded27',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/5f051fe3b5fcad8b573110349b992580.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd66b1a5ea86df135a6fc2b2fe404edb0',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/cf01f8a615b0ecc9600d5d24f9858d52.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2eacf565b6f8363ad1fc12dd8bc71ec6',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/cdb4fa2c99af8c89390991cb80206022.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'deb39bb113f61b66f65c24326b6bdb24',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/5836a5b3f4e637c83bb10366f4dcc6e8.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0b5d67e465986586813e6d1cab88e38',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/40b22250bf2ef49e7bb6c86a09d457be.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff3da97bb5d097a161a49a3f73d8f7bf',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/236845aaaee356d45acb6ea243b302bb.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65f1af12014572bf1455e8033fa49ae9',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/bed89ee2ce394cdaab922f16f75f6154.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc49f23a11d2a7240e9239050c83bc12',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/0499c9df2801c4a1cda5a9076a7a4d60.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad7f91170675876860e76fc4d086dc00',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/63ef214323b99a19a86c8f5648a987e1.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '361e5855f6d6f5ef4ff6b162d5b8dbcb',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/edfbcb9d7bab709cb8ac4947118df5ab.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8b8ae1e26e63b9bed6293b4bc177630',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/74866ae447335b205d3e84a24861b9ef.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e63cb616fd3e7f15d4acea947046b9af',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/bc8c29d1f837d4b7d2d1bc1b30081a8d.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cc23cb945dd2b67e4f6804b83dcc0d9',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/2cdb2ef78438889ab9f1b1f998b96f65.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a34eea0990057d8ee84df97ee738999c',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/b4cc140346c8eee181655cce8aa2a787.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5aea2e3a53828f7c79054568f296e606',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/ea0cd6ae9cc95bacf2aec48d71a0bbea.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '507415d391f9a16d20de7ee8c6861f6f',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/141419cf20d52eae918943fd68097ecd.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16ffe4a1613fb41cc62bb5b7cd718f58',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/2d76da0cf7ba010b9e5b5a20961022be.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd187fb640c1539117b62d788c4bb16e',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/3c70ce7311cbf7f65ba2fee9c1b77f99.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b16bd22b7ac910880c6bdcb3de301ee',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/08358be065c900630cdfd836b7d71baa.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '874b9dc472b25e0ac21f1d40e3a5076e',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/a5d1df85ea90a8ed4a4ef3e80aa723b8.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f122303a41dc73e7cb1a015024891045',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/a94b2afa9c30cda9e9f75f39066365bb.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9106e84c42d9214a210fbd1c76d5c96',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/172c5160d4ed46675283bd80cbcc6f90.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd08c9dbae6e876b144a103627fc9922a',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/ea2f94e6ed7fff22544c8932dc7ad3a0.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '343cd8edb8af1de9b7fa539205d87126',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/23e9550fa21ad9546ecb5e3ae92f2c9c.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00768d2fb181d10c81c1cfb0f793a582',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/4fde66e3e8b6debbb61b55907beddafd.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0356b06d2d1273037c85ee4c1ccc885e',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/22bed2e8db40ab42adef09aaf93dc9a9.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a380275078651dc290610b3e9b562a53',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/18b5b121f832dfa0ed3a508f984bdca4.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb002baa1e48d15b449e4a500c9fcc70',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/30451ee8f4abe012f6f8480daf509abd.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bda0d0b067ffa4b504c12862094bf543',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/2909270b7b7977ae999edf37078cf2d4.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd13ef0911204645b1a203c15601b98b0',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/1c2aa9a7ad1eb1a91c52535fbc5cb4aa.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbba8e35fc062f40345f01e35e811242',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/036e4c46411153281ebc5442ebc275d6.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9af17d82a8418f36154e8e402c1a445b',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/d129171bac487fc129af44825b4653a8.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae8b1238aa4935c26b32900971372784',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/40bcff7d4e50773e245134ee946a1661.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '153f0013d252ab2d6f93a4f2e10e5d75',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/6ba3477ec5ae4c773e0d890d978dfeb6.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbb5fc093ca6f84f3300e09c78ee6ffc',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/0b416c053507cf8ca43d4aa0230083dd.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '8333cb6b5395b299831ff306a4cc2905',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/69d0d41c3775be4d112fa20bc634d539.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'c4d88c43048f57182ed42cd36e7567a5',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/2aef4371af6b0693d203406aa85c9db9.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '5cf31cddadc8186dd9595396a42d9103',
      'native_key' => 1,
      'filename' => 'modUserGroup/3583ac1ba269c7f131a6da9cf26c4179.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '816a2dc9183fe63d05076a85df0374fe',
      'native_key' => 1,
      'filename' => 'modDashboard/daa1c8626847e12fa6e9d86cc9a72795.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '9a900150416fda2bfbb9860c442a3426',
      'native_key' => 1,
      'filename' => 'modMediaSource/c21b2e440445db1552766346ffa29f3b.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '421e8f438209cb5491c0bc9d55ee6377',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/5f5a614e3d24b9f647bc1a40b0bc1ee9.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'd3ddc84d798ded5c68d3b27d3da41d84',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/bd04bdf36a9c4df601b18a848d5d69ec.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '96d1e5a85528d2cab9b44fe75d848ac5',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/00f848a58ea6faf18ecc4673d7b83582.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '9c7dd4fbedb726d224336f18665ae7f1',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/3d19ca0252258f2e603ac671c8b9686b.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '4cb46fbd7857a1f7c23608c8e52c988e',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/fda3aba0fd634d5f85ab4efda12cb53f.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '21898a686886dcf92fbc9c6ee126baa9',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/7f35187052c08ee626e4778a3be9690c.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'e19162d8a803e7bdfc9acbecbef51c89',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/befa7d01f6b66e84f7f726eed168dc2e.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '9139c2264d9a99c014cf436484ab7a87',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/d79e59fdb0a374cf38fe218e6c8c0de4.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '28f06f33f6451a03238739629df05054',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/ce2c68a59cd11ca4ac0f95f0de783d53.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '24851e8fb3cae67573d1f9c7dcb655aa',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/11a924cadfc35741a26b14bc39f02d33.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'f348e75b0e1af9afed56d5191fde0f4c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/bc757ed28e8fa017ca429172fcdc6683.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '9fc06b6508aabaf5a1a34c34df35c519',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/52e614d8325743223f564ab53592ef59.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '776e4153e9e0732a8d097cc739a839ce',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/c802c5c6502b0e413ec87b60ec827677.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '216a60305a8d2d0aa7e6c1fa0605e6a8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/aecfd464d0a5e0ba643540d74e85293b.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '7659fb58aa6c601dd7ef1661182e0b46',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/bc7916560c7a984370b97f17b0954f81.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'a7663e7fb70d28b8ad3073082adb0df4',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/3f2ce753aa9e5acaa046f0e24727dcd9.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '43a8afb20405b3881a9ac28b3f6616b4',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/87348a020d93fc4e42797e1efafcb19c.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '73e08b905bcd3ecef0727afadfa4a478',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/42ecfe802b6e486c5a12cb829657fd77.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a27b1028b09b1c16d01bed274de52896',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/08d8231f1698f263de329a1a236ea68b.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '598960227f4233e6a6e0e299e4a3ae62',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/ca60b451605733c24b1728645bde6420.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '14e771748dfc1cc24f9ce5a5ac06466a',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/210502944c56df9395e575034fcaf1be.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c1f968d4cf9795a5aaf0db202ae30990',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/174c5f8216a252d9ce6a773094c6246a.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e2c00064d2b472288f509c4cd72cf35c',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/01e2b61f9010817ca32ec4a4b71ecaeb.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '40c44e5836460b86bdfc540ca969ce9f',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/ffba4c037d27c11b7e76b47d5b4f704b.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e756143d8ee173f14f04b4eb354318af',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/3929ab007e08bf9ff2f096549b207f4d.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'af764cd0e4ca44700a4f3876941da5aa',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/bc28fd706afe2e28b25a789416b8b10f.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '970a8ac81353ed228298fa5c042c01a6',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/5362fc1a4c86bd39ee2d8581897dfd03.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6b79e87d4c827bf74f41f49f5f1be979',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/c07b898ee5e2879a9f511d9bae13c70c.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3e13f6ad9f71b346c2f310c39a8cd072',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/c7351d3644eb8804e9e3d10b98c668ae.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '4152e8e9a7acf91c6c0fb2f079209dab',
      'native_key' => 'web',
      'filename' => 'modContext/8c26af9c3c6f187c72f54c09c2a380b3.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '5b8b757e974eac75d83135bec07c291d',
      'native_key' => 'mgr',
      'filename' => 'modContext/78f9a8a8a57483be387752d3e2721e3c.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '75c27abd69b31bcfec971af681f043de',
      'native_key' => '75c27abd69b31bcfec971af681f043de',
      'filename' => 'xPDOFileVehicle/b74a8ab124b2c5cb079063fd023a906e.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '0912a89aecede72dadb69397f8f4bc88',
      'native_key' => '0912a89aecede72dadb69397f8f4bc88',
      'filename' => 'xPDOFileVehicle/4c1222226155ca5fc34f88c62ca57baa.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '434f9eecfc644391f5049f547d2779ab',
      'native_key' => '434f9eecfc644391f5049f547d2779ab',
      'filename' => 'xPDOFileVehicle/082548e247ca69715976e8acd111ff42.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '8e9284aad434e0ff14f2967471c34a9a',
      'native_key' => '8e9284aad434e0ff14f2967471c34a9a',
      'filename' => 'xPDOFileVehicle/921f4e2ef8d478bde16ec9b15a8d021e.vehicle',
    ),
  ),
);