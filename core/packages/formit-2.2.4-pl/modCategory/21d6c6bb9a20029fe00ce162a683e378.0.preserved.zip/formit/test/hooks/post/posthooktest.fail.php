<?php
$hook->addError('name','This is a failed hook.');
return false;